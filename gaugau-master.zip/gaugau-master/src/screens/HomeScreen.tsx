import * as React from 'react'
import { Text, View } from 'react-native'

const HomeScreen: React.FC = () => {
  return (
    <View>
      <Text>Hello World</Text>
    </View>
  )
}

export default HomeScreen
